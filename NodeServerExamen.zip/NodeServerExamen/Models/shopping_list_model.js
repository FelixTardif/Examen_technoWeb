class Article {
    constructor(name,quantity) {
        this.name = name;
        this.quantity = quantity;
    }
}

module.exports = Article;