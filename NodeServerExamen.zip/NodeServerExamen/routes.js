let express = require('express');
let router = express.Router();
let connection = require('./database');
let shopping_list_controller = require('./Controllers/shopping_list_controller');

//Routes
router.get('/', shopping_list_controller.shoppingList); // Display the shopping list
router.get('/ajouter', shopping_list_controller.addArticleForm); // Send form to add new article
router.post('/',shopping_list_controller.addArticle); //Add new article in db
router.get('/delete/:i',shopping_list_controller.deleteArticle); //Delete article from db
router.get('/achete/:i',shopping_list_controller.buyArticle) //Update article state in shopping list



module.exports = router;