let express = require('express');
let app = express();

app.use(express.urlencoded({extended : true}));
app.use(express.static(__dirname + '/public'));

let routes = require('./routes');
app.use('/', routes);

app.listen(3000,function() {
    console.log('Server is running on port 3000');
});
