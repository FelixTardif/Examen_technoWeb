let mysql = require('mysql');
// connection à la DB
let connection = mysql.createConnection({ 
	host : 'localhost',
	user : 'root',
	password : 'root',
	database : 'db_examen'
});
connection.connect(function(error){ if (error) console.log(error);});

module.exports = connection;